<!DOCTYPE html>
<html>
<head>
	<title>Set New Password</title>
	<meta charset="UTF-8">
 	<link rel="stylesheet" href="css/style.css">

</head>
<body>
	<img src="medfocuslogo.png" alt="medfocuslogo">
	<div class="form">
		<form action="" class="login-form">
			<input type="password" placeholder="Default Password">
			<input type="password" placeholder="New Password">
			<input type="password" placeholder="Confirm New Password">
			<button>Submit</button>
		</form>
	</div>
</body>
</html>