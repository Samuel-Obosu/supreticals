<?php 
	session_start();
	if(isset($_GET['id'])){
		$id = $_GET['id'];
	}

	$counter = 1;

	if($id == "add_item"){
		
	}
 ?>